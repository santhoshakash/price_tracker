import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchCryptoData,
  selectCryptoData,
  selectCurrentCrypto,
  setCurrentCrypto,
} from '../redux/cryptoSlice';
import { RootState, AppDispatch } from '../redux/store';

const CryptoTable: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const data = useSelector(selectCryptoData);
  const currentCrypto = useSelector(selectCurrentCrypto);
  const loading = useSelector((state: RootState) => state.crypto.loading);
  const error = useSelector((state: RootState) => state.crypto.error);

  useEffect(() => {
    const interval = setInterval(() => {
      dispatch(fetchCryptoData(currentCrypto));
    }, 5000);
    return () => clearInterval(interval);
  }, [dispatch, currentCrypto]);

  const handleChangeCrypto = (newCrypto: string) => {
    dispatch(setCurrentCrypto(newCrypto));
  };

  return (
    <div>
      <h1>{currentCrypto.toUpperCase()} Prices</h1>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      <table>
        <thead>
          <tr>
            <th>Price</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {data.map((entry, index) => (
            <tr key={index}>
              <td>{entry.price}</td>
              <td>{new Date(entry.timestamp).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={() => handleChangeCrypto('ethereum')}>
        Change to Ethereum
      </button>
      <button onClick={() => handleChangeCrypto('bitcoin')}>
        Change to Bitcoin
      </button>
      {/* Add more buttons or a modal/popup to change the stock or crypto */}
    </div>
  );
};

export default CryptoTable;
