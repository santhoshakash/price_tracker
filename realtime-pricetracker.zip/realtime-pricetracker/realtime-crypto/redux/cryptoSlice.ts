import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { RootState } from './store';

interface CryptoState {
    data: any[];
    loading: boolean;
    error: string | null;
    currentCrypto: string;
}

const initialState: CryptoState = {
    data: [],
    loading: false,
    error: null,
    currentCrypto: 'bitcoin',
};

export const fetchCryptoData = createAsyncThunk(
    'crypto/fetchCryptoData',
    async (crypto: string) => {
        const response = await axios.get(`http://localhost:3000/api/${crypto}`);
        console.log(response.data, "response.data")
        return response.data;
    }
);

const cryptoSlice = createSlice({
    name: 'crypto',
    initialState,
    reducers: {
        setCurrentCrypto(state, action) {
            state.currentCrypto = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchCryptoData.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchCryptoData.fulfilled, (state, action) => {
                state.loading = false;
                state.data = action.payload;
            })
            .addCase(fetchCryptoData.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    },
});

export const { setCurrentCrypto } = cryptoSlice.actions;
export const selectCryptoData = (state: RootState) => state.crypto.data;
export const selectCurrentCrypto = (state: RootState) => state.crypto.currentCrypto;
export const selectCryptoLoading = (state: RootState) => state.crypto.loading;
export const selectCryptoError = (state: RootState) => state.crypto.error;
export default cryptoSlice.reducer;
