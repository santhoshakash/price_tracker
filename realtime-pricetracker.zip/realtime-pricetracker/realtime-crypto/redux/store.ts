import { configureStore } from '@reduxjs/toolkit';
import cryptoReducer from './cryptoSlice';
import { loadState, saveState } from './localStorage';

const preloadedState = loadState();

const store = configureStore({
    reducer: {
        crypto: cryptoReducer,
    },
    preloadedState,
});

store.subscribe(() => {
    saveState(store.getState());
});

export default store;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
