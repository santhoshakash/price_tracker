import React from 'react';
import CryptoTable from '../../components/CryptoTable';

const Home: React.FC = () => {
  return (
    <div>
      <CryptoTable />
    </div>
  );
};

export default Home;
