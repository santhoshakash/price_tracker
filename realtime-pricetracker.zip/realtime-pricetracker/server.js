const express = require('express');
const axios = require('axios');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log('MongoDB connection error:', err));

// Define schemas for each cryptocurrency
const createCryptoSchema = (cryptoName) => new mongoose.Schema({
    price: Number,
    timestamp: Date,
}, { collection: cryptoName });

// Create models for each cryptocurrency
const models = {};
const symbols = ['bitcoin', 'ethereum', 'ripple', 'litecoin', 'cardano'];
symbols.forEach(symbol => {
    models[symbol] = mongoose.model(symbol.charAt(0).toUpperCase() + symbol.slice(1), createCryptoSchema(symbol));
});

// Function to generate a random price between min and max
const generateRandomPrice = (min, max) => {
    return (Math.random() * (max - min) + min).toFixed(2);
};

// Fetch and store data
const fetchAndStoreData = async () => {
    console.log("hi in fetch")
    for (let symbol of symbols) {
        try {
            const response = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${symbol}&vs_currencies=usd`);
            const data = response.data;
            console.log(response.data, "response.data");
            let price;
            if (data[symbol] && data[symbol].usd) {
                price = data[symbol].usd;
            } else {
                // Generate a random price if the data is not available
                price = generateRandomPrice(10, 100); // Adjust the range as needed
            }
            const cryptoModel = models[symbol];
            const cryptoData = new cryptoModel({
                price: price,
                timestamp: new Date(),
            });
            await cryptoData.save();
        } catch (error) {
            // console.error(`Error fetching data for ${symbol}:`, error.message);
        }
    }
};

// Fetch data every 5 minutes (300000 milliseconds)
setInterval(fetchAndStoreData, 30000);

// API Endpoint to get data for a specific cryptocurrency
app.get('/api/:crypto', async (req, res) => {
    const crypto = req.params.crypto.toLowerCase();
    console.log(crypto, "crypto")
    if (!models[crypto]) {
        return res.status(404).json({ error: 'Cryptocurrency not found' });
    }
    try {
        const data = await models[crypto].find().sort({ timestamp: -1 }).limit(50);
        console.log(data, "data in server result")
        res.json(data);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
